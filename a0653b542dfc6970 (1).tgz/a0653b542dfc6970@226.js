function _1(md){return(
md`Este notebook apresenta uma análise estatística da temporada 2023/2024 da Premier League.

Os dados foram tratados utilizando Pandas e posteriormente enviados ao GitHub para utilização no ObservableHQ.

O conjunto de dados contém informações sobre partidas da liga inglesa, incluindo gols, resultados, estatísticas ofensivas, faltas, cartões e escanteios.

O objetivo da análise é identificar padrões de desempenho das equipes, tendências ofensivas e comportamentos durante as partidas.`
)}

async function _dados(d3){return(
await d3.csv("https://raw.githubusercontent.com/josemateusalmeidaf-ai/Projeto-dados/refs/heads/main/dados_limpos.csv")
)}

function _embed(require){return(
require("vega-embed@5")
)}

function _4(embed){return(
`Embed: ${embed.version}, Vega: ${embed.vega.version}, Vega-Lite: ${embed.vl.version}`
)}

function _cell31(md){return(
md`# **Análise da Premier League 2023/2024**

## **Introdução**

Este notebook apresenta uma análise estatística da Premier League 2023/2024.
Os dados foram tratados utilizando Pandas e disponibilizados no GitHub para utilização no ObservableHQ.

O conjunto de dados contém estatísticas de partidas, gols, chutes, faltas, cartões e escanteios.

Date: data da partida
TimeCasa: time mandante
TimeFora: time visitante
GolsTimeCasaFT: gols do mandante
GolsTimeForaFT: gols do visitante
ResultadoFinal: resultado final
ChutesTimeCasa: total de chutes do mandante
ChutesTimeFora: total de chutes do visitante
EscanteiosTimeCasa: escanteios do mandante
EscanteiosTimeFora: escanteios do visitante`
)}

function _Plot(require){return(
require("@observablehq/plot")
)}

function _resultados(dados){return(
[
  {
    tipo: "Casa",
    quantidade: dados.filter(d => d.ResultadoFinal === "H").length
  },
  {
    tipo: "Visitante",
    quantidade: dados.filter(d => d.ResultadoFinal === "A").length
  },
  {
    tipo: "Empate",
    quantidade: dados.filter(d => d.ResultadoFinal === "D").length
  }
]
)}

function _8(Plot,resultados){return(
Plot.plot({
  marks: [
    Plot.barY(resultados, {
      x: "tipo",
      y: "quantidade"
    })
  ]
})
)}

function _9(md){return(
md`## Interpretação
O gráfico mostra a quantidade de vitórias dos mandantes, visitantes e empates.

## Conclusão
As equipes jogando em casa venceram mais partidas, indicando vantagem do fator casa.`
)}

async function _plotComparacaoTriplaHorizontalFora(d3,Plot)
{
  const dados = await d3.csv(
    "https://raw.githubusercontent.com/josemateusalmeidaf-ai/Projeto-dados/refs/heads/main/dados_limpos.csv"
  );

  const vitorias = {};
  const derrotas = {};
  const empates = {};

  dados.forEach((jogo) => {
    const timeCasa = jogo.TimeCasa;
    const timeFora = jogo.TimeFora;
    const resultado = jogo.ResultadoFinal;

    if (resultado === "H") {
      vitorias[timeCasa] = (vitorias[timeCasa] || 0) + 1;
      derrotas[timeFora] = (derrotas[timeFora] || 0) + 1;
    } else if (resultado === "A") {
      vitorias[timeFora] = (vitorias[timeFora] || 0) + 1;
      derrotas[timeCasa] = (derrotas[timeCasa] || 0) + 1;
    } else if (resultado === "D") {
      empates[timeCasa] = (empates[timeCasa] || 0) + 1;
      empates[timeFora] = (empates[timeFora] || 0) + 1;
    }
  });

  const todosTimes = new Set([
    ...Object.keys(vitorias),
    ...Object.keys(derrotas),
    ...Object.keys(empates)
  ]);

  const dadosTripla = Array.from(todosTimes)
    .map((time) => ({
      time: time,
      V: vitorias[time] || 0,
      E: empates[time] || 0,
      D: derrotas[time] || 0
    }))
    .sort((a, b) => b.V - a.V);

  const dadosLong = [];
  dadosTripla.forEach((d) => {
    dadosLong.push({ time: d.time, tipo: "V", valor: d.V });
    dadosLong.push({ time: d.time, tipo: "E", valor: d.E });
    dadosLong.push({ time: d.time, tipo: "D", valor: d.D });
  });

  return Plot.plot({
    title: "📊 Vitórias (V), Empates (E) e Derrotas (D) por Time",
    subtitle: "V (verde) | E (amarelo) | D (vermelho)",
    width: 1100,
    height: 900,
    marginLeft: 180,
    marginRight: 120,
    x: {
      label: "Número de Jogos",
      grid: true
    },
    y: {
      label: "Times",
      domain: dadosTripla.map((d) => d.time)
    },
    color: {
      legend: true,
      label: "Resultado",
      domain: ["V", "E", "D"],
      range: ["#2ca02c", "#ffd700", "#d62728"]
    },
    marks: [
      Plot.barX(dadosLong, {
        y: "time",
        x: "valor",
        fill: "tipo",
        fillOpacity: 0.85,
        title: (d) => `${d.time}\n${d.tipo}: ${d.valor}`
      }),
      // Texto completo no final (ex: V:28, E:7, D:3)
      Plot.text(dadosTripla, {
        y: "time",
        x: (d) => d.V + d.E + d.D + 2,
        text: (d) => `V:${d.V}  E:${d.E}  D:${d.D}`,
        dx: 5,
        fontSize: 10,
        fill: "#333",
        fontWeight: "bold",
        textAnchor: "start"
      })
    ]
  });
}


function _11(md){return(
md`**Interpretação**

O gráfico mostra Vitórias (verde), Empates (amarelo) e Derrotas (vermelho) de cada time em barras horizontais. Times no topo têm mais vitórias. O número exato aparece no final de cada barra (V: X, E: Y, D: Z).

**Conclusão**

Times com mais verde dominaram a competição. Times com muito vermelho tiveram campanhas fracas. Muitos empates indicam dificuldade para vencer jogos decisivos.`
)}

async function _plotComparacaoFaltasHorizontal(d3,Plot)
{
  const dados = await d3.csv(
    "https://raw.githubusercontent.com/josemateusalmeidaf-ai/Projeto-dados/refs/heads/main/dados_limpos.csv"
  );

  const faltasCasa = {};
  dados.forEach((jogo) => {
    const time = jogo.TimeCasa;
    const faltas = parseInt(jogo.FaltasTimeCasa) || 0;
    faltasCasa[time] = (faltasCasa[time] || 0) + faltas;
  });

  const faltasFora = {};
  dados.forEach((jogo) => {
    const time = jogo.TimeFora;
    const faltas = parseInt(jogo.FaltasTimeFora) || 0;
    faltasFora[time] = (faltasFora[time] || 0) + faltas;
  });

  const todosTimes = new Set([
    ...Object.keys(faltasCasa),
    ...Object.keys(faltasFora)
  ]);

  const faltasArray = Array.from(todosTimes)
    .map((time) => ({
      time: time,
      Casa: faltasCasa[time] || 0,
      Fora: faltasFora[time] || 0,
      Total: (faltasCasa[time] || 0) + (faltasFora[time] || 0)
    }))
    .sort((a, b) => b.Total - a.Total);

  const dadosLong = [];
  faltasArray.forEach((d) => {
    dadosLong.push({ time: d.time, local: "Casa", faltas: d.Casa });
    dadosLong.push({ time: d.time, local: "Fora", faltas: d.Fora });
  });

  return Plot.plot({
    title: "🏟️ Comparação de Faltas: Casa vs Fora",
    subtitle: "Versão horizontal para melhor leitura dos nomes",
    width: 1100,
    height: 800,
    marginLeft: 180,
    x: {
      label: "Total de Faltas",
      grid: true
    },
    y: {
      label: "Times",
      domain: faltasArray.map((d) => d.time)
    },
    color: {
      legend: true,
      label: "Local",
      domain: ["Casa", "Fora"],
      range: ["#ffcc00", "#ff7f0e"]
    },
    marks: [
      Plot.barX(dadosLong, {
        y: "time",
        x: "faltas",
        fill: "local",
        fillOpacity: 0.85,
        title: (d) => `${d.time}\n${d.local}: ${d.faltas} faltas`
      }),
      Plot.text(dadosLong, {
        y: "time",
        x: "faltas",
        text: (d) => (d.faltas > 0 ? d.faltas : ""),
        dx: 5,
        fontSize: 9,
        fill: "#333",
        fontWeight: "bold"
      })
    ]
  });
}


function _13(md){return(
md`**Interpretação**

O gráfico mostra o total de faltas cometidas por cada time jogando em Casa (amarelo) e Fora (laranja). Times ordenados do que mais cometeu faltas (topo) ao que menos cometeu (base). O número exato aparece ao final de cada barra.

**Conclusão**

[LIGAÇÃO COM GRÁFICO ANTERIOR]

Times que tiveram muitas vitórias (verde no gráfico anterior) geralmente cometem menos faltas, pois controlam mais o jogo. Times com muitas derrotas (vermelho) tendem a cometer mais faltas, por estarem na defensiva.

Times que cometem muitas faltas em casa podem ter estilo de jogo mais agressivo. Já times com muitas faltas fora demonstram dificuldade para se adaptar ao campo adversário.`
)}

async function _plotInvestimentosHorizontal(d3,Plot)
{
  const dados = await d3.csv(
    "https://raw.githubusercontent.com/josemateusalmeidaf-ai/Projeto-dados/refs/heads/main/transfer_addP.csv"
  );

  const investimentosArray = dados
    .map((d) => ({
      clube: d.Clube,
      gasto: parseFloat(d["Gasto Bruto (Milhões de Euros)"])
    }))
    .sort((a, b) => b.gasto - a.gasto); // Ordena do maior para o menor

  return Plot.plot({
    title: "💰 Clubes que Mais Investiram no Campeonato",
    width: 1000,
    height: 600,
    marginLeft: 180,
    x: {
      label: "Gasto Bruto (Milhões de Euros)",
      grid: true
    },
    y: {
      label: "Clube",
      tickFormat: (d) => d,
      domain: investimentosArray.map((d) => d.clube) // FORÇA a ordem do array
    },
    marks: [
      Plot.barX(investimentosArray, {
        y: "clube",
        x: "gasto",
        fill: "#2ca02c",
        title: (d) => `${d.clube}: €${d.gasto}M`
      }),
      Plot.text(investimentosArray, {
        y: "clube",
        x: "gasto",
        text: (d) => `€${d.gasto}M`,
        dx: 5,
        fill: "#333",
        fontSize: 10
      })
    ]
  });
}


function _15(md){return(
md`**Interpretação**

O gráfico mostra os clubes ordenados do que mais investiu (topo) ao que menos investiu (base) em milhões de euros. A barra verde representa o gasto bruto em contratações.

**Conclusão**

[LIGAÇÃO COM GRÁFICOS ANTERIORES]

Comparando com os dois gráficos anteriores (Vitórias/Empates/Derrotas e Faltas):

1. **Chelsea** lidera em investimento (€464M) e também liderava em faltas cometidas. No primeiro gráfico, teve campanha mediana (nem mais vitórias, nem mais derrotas). Investimento alto não gerou desempenho proporcional.

2. **Manchester City** (3º em investimento) foi o time com mais vitórias no primeiro gráfico. Alta eficiência: gastou bem menos que o Chelsea mas conquistou mais resultados.

3. **Luton Town** (menor investidor, €27M) teve muitas derrotas no primeiro gráfico. Relação direta: baixo investimento → time frágil.

4. **Tottenham** (2º em investimento) teve muitas faltas cometidas (gráfico anterior) mas campanha equilibrada em vitórias/derrotas.

**Resumo:** Investimento não garante vitórias (Chelsea prova isso), mas falta de investimento quase sempre significa derrotas (Luton). O segredo está em como o time converte gasto em resultado (Manchester City é o exemplo de eficiência).`
)}

async function _plotComparacaoDumbbell(d3,Plot)
{
  const dados = await d3.csv(
    "https://raw.githubusercontent.com/josemateusalmeidaf-ai/Projeto-dados/refs/heads/main/dados_limpos.csv"
  );

  const chutesCasa = {};
  const chutesFora = {};

  dados.forEach((jogo) => {
    const timeCasa = jogo.TimeCasa;
    const timeFora = jogo.TimeFora;
    const chutesC = parseInt(jogo.ChutesTimeCasa) || 0;
    const chutesF = parseInt(jogo.ChutesTimeFora) || 0;

    chutesCasa[timeCasa] = (chutesCasa[timeCasa] || 0) + chutesC;
    chutesFora[timeFora] = (chutesFora[timeFora] || 0) + chutesF;
  });

  const todosTimes = new Set([
    ...Object.keys(chutesCasa),
    ...Object.keys(chutesFora)
  ]);
  const dadosComparacao = Array.from(todosTimes)
    .map((time) => ({
      time: time,
      Casa: chutesCasa[time] || 0,
      Fora: chutesFora[time] || 0,
      Diferenca: (chutesCasa[time] || 0) - (chutesFora[time] || 0)
    }))
    .sort((a, b) => b.Casa - a.Casa);

  const formatNumber = (n) => n.toLocaleString("pt-BR");

  return Plot.plot({
    title: "📊 Comparação de Chutes: Casa vs Fora",
    subtitle:
      "Números em azul = Chutes em Casa | Números em laranja = Chutes Fora",
    width: 1000,
    height: 800,
    marginLeft: 180,
    x: {
      label: "Total de Chutes",
      grid: true,
      tickFormat: (d) => formatNumber(d)
    },
    y: {
      label: "Times",
      domain: dadosComparacao.map((d) => d.time)
    },
    marks: [
      // Linhas conectando casa e fora
      Plot.ruleX(dadosComparacao, {
        y: "time",
        x1: "Fora",
        x2: "Casa",
        stroke: "#999",
        strokeWidth: 1.5,
        strokeDasharray: "4",
        title: (d) =>
          `${d.time}\nDiferença: ${d.Diferenca > 0 ? "+" : ""}${formatNumber(
            d.Diferenca
          )}`
      }),

      // Pontos para casa (azul)
      Plot.dot(dadosComparacao, {
        y: "time",
        x: "Casa",
        fill: "#1f77b4",
        r: 10,
        title: (d) => `${d.time}\n🏠 CASA: ${formatNumber(d.Casa)} chutes`
      }),

      // Número do casa ACIMA do círculo
      Plot.text(dadosComparacao, {
        y: "time",
        x: "Casa",
        text: (d) => `${formatNumber(d.Casa)}`,
        dy: -15, // Posiciona acima
        dx: 0,
        fontSize: 10,
        fill: "#1f77b4",
        fontWeight: "bold",
        textAnchor: "middle"
      }),

      // Pontos para fora (laranja)
      Plot.dot(dadosComparacao, {
        y: "time",
        x: "Fora",
        fill: "#ff7f0e",
        r: 10,
        title: (d) => `${d.time}\n✈️ FORA: ${formatNumber(d.Fora)} chutes`
      }),

      // Número do fora ABAIXO do círculo
      Plot.text(dadosComparacao, {
        y: "time",
        x: "Fora",
        text: (d) => `${formatNumber(d.Fora)}`,
        dy: 18, // Posiciona abaixo
        dx: 0,
        fontSize: 10,
        fill: "#ff7f0e",
        fontWeight: "bold",
        textAnchor: "middle"
      }),

      // Indicador de diferença no meio da linha
      Plot.text(dadosComparacao, {
        y: "time",
        x: (d) => (d.Casa + d.Fora) / 2,
        text: (d) => {
          const diff = Math.abs(d.Diferenca);
          if (diff < 50) return "";
          return d.Diferenca > 0
            ? `▲ ${formatNumber(diff)}`
            : `▼ ${formatNumber(diff)}`;
        },
        dx: 0,
        dy: -8,
        fontSize: 9,
        fill: (d) => (d.Diferenca > 0 ? "#1f77b4" : "#ff7f0e"),
        fontWeight: "bold",
        textAnchor: "middle"
      })
    ]
  });
}


function _17(md){return(
md`**Interpretação**

O gráfico mostra o total de chutes a gol de cada time jogando em Casa (círculo azul) e Fora (círculo laranja). Os times estão ordenados do que mais chutou em casa (topo) ao que menos chutou (base). Linhas tracejadas conectam os dois valores. A diferença (▲ ou ▼) aparece no meio quando é relevante.

**Conclusão**

[LIGAÇÃO COM GRÁFICOS ANTERIORES]

**Relação com Vitórias (1º gráfico):**
- Times com muitas vitórias (ex: Manchester City, Arsenal) geralmente têm mais chutes em casa E fora.
- Times com muitas derrotas (ex: Sheffield United, Luton) têm poucos chutes, principalmente fora.

**Relação com Investimento (3º gráfico):**
- Chelsea (maior investidor, €464M) tem bom número de chutes, mas desempenho mediano em vitórias — chute não virou gol.
- Manchester City (3º investidor) tem excelente volume de chutes e converteu em vitórias.

**Relação com Faltas (2º gráfico):**
- Times agressivos que cometem muitas faltas (ex: Chelsea) também costumam ter muitos chutes.
- Times violentos mas ineficientes: muitas faltas, poucos chutes (ex: Everton).

**Padrão importante:**
- A maioria dos times tem chutes EM CASA maiores que FORA — efeito mandante real.
- Times que quebram essa regra (chutes fora > casa) geralmente são os mais vitoriosos (City, Liverpool, Arsenal).

**Resumo:** Chutes são métrica de domínio. Quem chuta mais, vence mais. Quem chuta pouco fora de casa, perde ou empata. Investimento ajuda a gerar chutes, mas não garante eficiência (gols).`
)}

async function _plotComparacaoEscanteiosEstilizado(d3,Plot)
{
  const dados = await d3.csv(
    "https://raw.githubusercontent.com/josemateusalmeidaf-ai/Projeto-dados/refs/heads/main/dados_limpos.csv"
  );

  const escanteiosCasa = {};
  dados.forEach((jogo) => {
    const time = jogo.TimeCasa;
    const escanteios = parseInt(jogo.EscanteiosTimeCasa) || 0;
    escanteiosCasa[time] = (escanteiosCasa[time] || 0) + escanteios;
  });

  const escanteiosFora = {};
  dados.forEach((jogo) => {
    const time = jogo.TimeFora;
    const escanteios = parseInt(jogo.EscanteiosTimeFora) || 0;
    escanteiosFora[time] = (escanteiosFora[time] || 0) + escanteios;
  });

  const todosTimes = new Set([
    ...Object.keys(escanteiosCasa),
    ...Object.keys(escanteiosFora)
  ]);
  const dadosComparacao = Array.from(todosTimes)
    .map((time) => ({
      time: time,
      Casa: escanteiosCasa[time] || 0,
      Fora: escanteiosFora[time] || 0
    }))
    .sort((a, b) => b.Casa - a.Casa);

  const dadosLong = [];
  dadosComparacao.forEach((d) => {
    dadosLong.push({ time: d.time, local: "Casa", escanteios: d.Casa });
    dadosLong.push({ time: d.time, local: "Fora", escanteios: d.Fora });
  });

  return Plot.plot({
    title: "🏁 Comparação de Escanteios: Casa vs Fora",
    subtitle: "Total de escanteios a favor por time",
    width: 1200,
    height: 600,
    marginBottom: 120,
    marginLeft: 60,
    x: {
      label: "Times",
      tickRotate: -45,
      domain: dadosComparacao.map((d) => d.time)
    },
    y: {
      label: "Total de Escanteios",
      grid: true
    },
    color: {
      legend: true,
      label: "Local do Jogo",
      domain: ["Casa", "Fora"],
      range: ["#27ae60", "#e74c3c"] // Verde escuro e Vermelho
    },
    marks: [
      Plot.barY(dadosLong, {
        x: "time",
        y: "escanteios",
        fill: "local",
        fillOpacity: 0.9,
        stroke: "local",
        strokeWidth: 1,
        title: (d) => `${d.time}\n${d.local}: ${d.escanteios} escanteios`
      }),
      // Adicionar rótulos com os valores
      Plot.text(dadosLong, {
        x: "time",
        y: "escanteios",
        text: (d) => (d.escanteios > 0 ? d.escanteios : ""),
        dy: -6,
        fontSize: 9,
        fill: "#333"
      })
    ]
  });
}


function _19(md){return(
md`**Interpretação**

O gráfico mostra o total de escanteios a favor de cada time jogando em Casa (verde) e Fora (vermelho). Os times estão ordenados do que teve mais escanteios em casa (esquerda) ao que teve menos (direita). O número aparece no topo de cada barra.

**Conclusão**

[LIGAÇÃO COM TODOS OS GRÁFICOS ANTERIORES]

**Relação com Vitórias (1º gráfico):**
- Times com mais vitórias (Manchester City, Arsenal, Liverpool) lideram em escanteios tanto em casa quanto fora.
- Times com muitas derrotas (Sheffield United, Luton) têm poucos escanteios, principalmente fora.

**Relação com Chutes (4º gráfico):**
- Escanteios seguem o mesmo padrão dos chutes: times que atacam mais → mais escanteios.
- Brighton tem muitos escanteios em casa (verde alto), mas menos vitórias — escanteio não virou gol.

**Relação com Investimento (3º gráfico):**
- Chelsea (maior investidor) tem escanteios medianos — gastou muito mas não dominou jogadas aéreas.
- Manchester City (investimento médio) lidera escanteios — eficiência tática.

**Relação com Faltas (2º gráfico):**
- Times que cometem muitas faltas (Everton, Chelsea) não necessariamente têm muitos escanteios.
- Agressividade sem domínio de jogo não gera escanteios.

**Padrão importante:**
- Efeito mandante forte: todos os times têm MAIS escanteios em casa do que fora.
- A diferença casa-fora nos escanteios é maior que nos chutes — torcida influencia mais bolas paradas.


**Aprendizado principal:** Ter a bola e atacar (chutes + escanteios) é o que realmente leva a vitórias. Investimento ajuda, mas não garante. Faltas atrapalham.`
)}

async function _plotComparacaoCampeaoVice(d3,Plot)
{
  const dados = await d3.csv(
    "https://raw.githubusercontent.com/josemateusalmeidaf-ai/Projeto-dados/refs/heads/main/dados_limpos.csv"
  );

  const times = ["Man City", "Arsenal"];
  const evolucaoTimes = {};

  for (const time of times) {
    let pontos = 0;
    evolucaoTimes[time] = [];
    let jogos = 0;

    for (const jogo of dados) {
      const timeCasa = jogo.TimeCasa;
      const timeFora = jogo.TimeFora;
      const resultado = jogo.ResultadoFinal;

      let pontosJogo = 0;
      let jogou = false;

      if (timeCasa === time) {
        jogou = true;
        if (resultado === "H") pontosJogo = 3;
        if (resultado === "D") pontosJogo = 1;
      } else if (timeFora === time) {
        jogou = true;
        if (resultado === "A") pontosJogo = 3;
        if (resultado === "D") pontosJogo = 1;
      }

      if (jogou) {
        jogos++;
        pontos += pontosJogo;
        evolucaoTimes[time].push({ rodada: jogos, pontos: pontos });
      }
    }
  }

  // Combinar dados para o gráfico
  const dadosComparacao = [];
  for (const time of times) {
    for (const ponto of evolucaoTimes[time]) {
      dadosComparacao.push({
        time: time,
        rodada: ponto.rodada,
        pontos: ponto.pontos
      });
    }
  }

  return Plot.plot({
    title: "🏆 Comparação: Campeão (Man City) vs Vice (Arsenal)",
    subtitle: "Evolução da pontuação ao longo do campeonato",
    width: 1100,
    height: 500,
    x: {
      label: "Rodada",
      grid: true,
      domain: [1, 38]
    },
    y: {
      label: "Pontos Acumulados",
      grid: true,
      domain: [0, 95]
    },
    color: {
      legend: true,
      label: "Time",
      domain: times,
      range: ["#1f77b4", "#d62728"]
    },
    marks: [
      Plot.line(dadosComparacao, {
        x: "rodada",
        y: "pontos",
        stroke: "time",
        strokeWidth: 2.5
      }),
      Plot.dot(dadosComparacao, {
        x: "rodada",
        y: "pontos",
        fill: "time",
        r: 4
      })
    ]
  });
}


function _21(md){return(
md`**Interpretação**

O gráfico mostra a evolução da pontuação acumulada de Manchester City (azul) e Arsenal (vermelho) ao longo das 38 rodadas. A linha sobe a cada jogo. O campeão é quem terminar com mais pontos.

**Conclusão**

[LIGAÇÃO COM TODOS OS GRÁFICOS ANTERIORES]

**Análise da corrida pelo título:**

- **Arsenal começou melhor:** Nas primeiras rodadas, o vice liderou a disputa.
- **Man City foi consistente:** Azul manteve crescimento constante sem quedas bruscas.
- **Virada decisiva:** Meio do campeonato → City ultrapassou Arsenal e não perdeu mais a liderança.
- **Arsenal oscilou:** Vice teve tropeços em momentos críticos (perdeu pontos em jogos que o City venceu).

**O que fez a diferença:**

1. **Eficiência:** City transformou chutes/escanteios em gols e vitórias com mais aproveitamento que Arsenal.
2. **Consistência mental:** Não oscilou na reta final (Arsenal perdeu pontos contra times fracos).
3. **Disciplina:** City cometeu poucas faltas → menos suspensões e jogos controlados.
4. **Experiência:** Time campeão soube administrar vantagem após ultrapassar o rival.

**Aprendizado principal do campeonato:**  
*Não basta investir muito (Chelsea) ou ter bons números de ataque (Arsenal). O campeão (Man City) combina: investimento eficiente + domínio de jogo (chutes/escanteios) + disciplina (poucas faltas) + regularidade psicológica.*`
)}

async function _plotComparacaoInvestimento(d3,Plot)
{
  const dados = await d3.csv(
    "https://raw.githubusercontent.com/josemateusalmeidaf-ai/Projeto-dados/refs/heads/main/transfer_addP.csv"
  );

  // Filtrar apenas Man City e Arsenal
  const timesFiltrados = dados.filter(
    (d) => d.Clube === "Manchester City" || d.Clube === "Arsenal FC"
  );

  const dadosComparacao = timesFiltrados.map((d) => ({
    time:
      d.Clube === "Manchester City"
        ? "🏆 Manchester City (Campeão)"
        : "🥈 Arsenal FC (Vice)",
    gasto: parseFloat(d["Gasto Bruto (Milhões de Euros)"]),
    contratacao: d["Contratação Mais Cara"],
    valorContratacao: d.Clube === "Manchester City" ? 241.1 : 234.94
  }));

  return Plot.plot({
    title: "💰 Comparação de Investimento: Campeão vs Vice",
    subtitle: "Gasto bruto em contratações (milhões de euros)",
    width: 800,
    height: 400,
    marginBottom: 50,
    marginLeft: 200,
    x: {
      label: "Gasto Bruto (Milhões de Euros)",
      grid: true
    },
    y: {
      label: "",
      domain: dadosComparacao.map((d) => d.time)
    },
    color: {
      domain: ["🏆 Manchester City (Campeão)", "🥈 Arsenal FC (Vice)"],
      range: ["#1f77b4", "#d62728"]
    },
    marks: [
      Plot.barX(dadosComparacao, {
        y: "time",
        x: "gasto",
        fill: "time",
        fillOpacity: 0.85,
        title: (d) =>
          `${d.time}\nGasto: €${d.gasto}M\nContratação mais cara: ${d.contratacao} (€${d.valorContratacao}M)`
      }),
      Plot.text(dadosComparacao, {
        y: "time",
        x: "gasto",
        text: (d) => `€${d.gasto}M`,
        dx: 8,
        fontSize: 12,
        fill: "#333",
        fontWeight: "bold"
      })
    ]
  });
}


function _23(md){return(
md`**Interpretação**

O gráfico mostra o gasto bruto em contratações (milhões de euros) do Manchester City (campeão) e do Arsenal (vice). As barras horizontais permitem comparar diretamente o investimento dos dois times.

**Conclusão**

[LIGAÇÃO COM TODOS OS GRÁFICOS ANTERIORES]

**Comparação direta:**

| Indicador | 🏆 Man City (Campeão) | 🥈 Arsenal (Vice) | Diferença |
|-----------|---------------------|-------------------|------------|
| Gasto total | €241,1M | €234,94M | City gastou **€6,16M a mais** |
| Contratação mais cara | Josko Gvardiol (€241,1M) | Declan Rice (€234,94M) | Valores muito próximos |
| Posição no ranking | 3º maior investidor | 4º maior investidor | Investimento similar |

**O que isso explica sobre a campanha:**

1. **Investimento similar, resultados diferentes:** Os dois gastaram praticamente o mesmo valor, mas o City foi campeão. Isso prova que **não foi o dinheiro que decidiu** o título.

2. **Eficiência do City:** Com investimento equivalente, o campeão teve:
   - Mais vitórias (1º gráfico)
   - Mais chutes (4º gráfico)
   - Mais escanteios (5º gráfico)
   - Menos faltas (2º gráfico)

3. **Onde o Arsenal pecou:** Mesmo gastando quase o mesmo que o City, o vice:
   - Oscilou mais (gráfico da evolução)
   - Perdeu pontos para times menores
   - Teve menos eficiência ofensiva

4. **Comparação com o maior investidor (Chelsea):**
   - Chelsea gastou **€464,1M** (quase o dobro)
   - Ficou atrás de ambos na tabela
   - **Prova definitiva:** Investimento sozinho NÃO ganha campeonato

**Aprendizado definitivo do campeonato:**

*Ganhar não é só gastar. É gastar bem, dominar o jogo (chutes/escanteios), ser disciplinado (poucas faltas) e manter a regularidade. O Arsenal investiu quase igual ao City, mas pecou na oscilação. O Chelsea investiu o dobro e falhou em tudo.*

**Fórmula do título (Man City):**  
\`Investimento eficiente + Domínio tático + Disciplina + Regularidade mental = CAMPEÃO\``
)}

async function _plotInvestimentoVsPosicao(d3,Plot)
{
  const transferData = await d3.csv(
    "https://raw.githubusercontent.com/josemateusalmeidaf-ai/Projeto-dados/refs/heads/main/transfer_addP.csv"
  );

  // Dados de posição final (aproximada baseada nos resultados)
  const posicoesFinais = {
    "Manchester City": 1,
    "Arsenal FC": 2,
    "Liverpool FC": 3,
    "Aston Villa": 4,
    "Tottenham Hotspur": 5,
    "Chelsea FC": 6,
    "Newcastle United": 7,
    "Manchester United": 8,
    "West Ham United": 9,
    "Crystal Palace": 10,
    "Brighton & Hove Albion": 11,
    "AFC Bournemouth": 12,
    "Fulham FC": 13,
    "Wolverhampton Wanderers": 14,
    "Everton FC": 15,
    "Brentford FC": 16,
    "Nottingham Forest": 17,
    "Luton Town": 18,
    "Burnley FC": 19,
    "Sheffield United": 20
  };

  const dados = transferData
    .map((d) => ({
      clube: d.Clube,
      gasto: parseFloat(d["Gasto Bruto (Milhões de Euros)"]),
      posicao: posicoesFinais[d.Clube] || 99,
      categoria:
        parseFloat(d["Gasto Bruto (Milhões de Euros)"]) > 150
          ? "💰 Mais Investiu"
          : "📉 Menos Investiu"
    }))
    .sort((a, b) => a.posicao - b.posicao);

  return Plot.plot({
    title: "💰 Relação: Investimento vs Posição Final",
    subtitle:
      "Barras verdes = investimento acima de €150M | Vermelhas = abaixo",
    width: 1200,
    height: 600,
    marginBottom: 120,
    x: {
      label: "Times (ordenados por posição final)",
      tickRotate: -45,
      domain: dados.map((d) => d.clube)
    },
    y: {
      label: "Gasto Bruto (Milhões de Euros)",
      grid: true
    },
    color: {
      legend: true,
      label: "Categoria",
      domain: ["💰 Mais Investiu", "📉 Menos Investiu"],
      range: ["#2ca02c", "#d62728"]
    },
    marks: [
      Plot.barY(dados, {
        x: "clube",
        y: "gasto",
        fill: "categoria",
        fillOpacity: 0.85,
        title: (d) =>
          `${d.clube}\nInvestimento: €${d.gasto}M\nPosição: ${d.posicao}º`
      }),
      Plot.text(dados, {
        x: "clube",
        y: "gasto",
        text: (d) => `${d.gasto}M`,
        dy: -8,
        fontSize: 9,
        fill: "#333",
        fontWeight: "bold"
      }),
      Plot.text(dados, {
        x: "clube",
        y: 0,
        text: (d) => `#${d.posicao}`,
        dy: 15,
        fontSize: 10,
        fill: "#fff",
        fontWeight: "bold",
        stroke: "#333",
        strokeWidth: 0.5
      })
    ]
  });
}


function _25(md){return(
md`**Interpretação**

O gráfico mostra a relação entre quanto cada clube investiu (barra verde: acima de €150M; barra vermelha: abaixo) e sua posição final no campeonato (número # dentro da barra). Os times estão ordenados da esquerda (1º lugar) para a direita (20º lugar).

**Conclusão**

[LIGAÇÃO COM TODOS OS GRÁFICOS ANTERIORES]

**Correlação investimento vs posição (evidências dos 6 gráficos):**

1. **TOP 3 que mais investiram:**
   - Chelsea (€464M) → 6º lugar ❌
   - Tottenham (€272M) → 5º lugar ❌
   - Man City (€241M) → 1º lugar ✅

2. **Eficiência extrema (bom retorno):**
   - Aston Villa: €93M → 4º lugar (investiu 5x menos que Chelsea, ficou 2 posições acima)
   - Liverpool: €172M → 3º lugar
   - Brighton: €84M → 11º lugar (investimento baixo, meio de tabela)

3. **Ineficiência extrema (retorno negativo):**
   - Chelsea: maior investidor → 6º lugar
   - Man United: 5º investidor → 8º lugar
   - Tottenham: 2º investidor → 5º lugar

**Resumo final de todas as análises (6 gráficos):**

**Gráfico 1 (Vitórias):** Quem ganha mais? → Man City  
**Gráfico 2 (Faltas):** Quem é mais disciplinado? → Man City  
**Gráfico 3 (Investimento inicial):** Quem mais gastou? → Chelsea  
**Gráfico 4 (Chutes):** Quem domina o jogo? → Man City  
**Gráfico 5 (Escanteios):** Quem pressiona mais? → Man City  
**Gráfico 6 (Investimento vs Posição):** Gasto vira resultado? → **NEM SEMPRE**

**Aprendizado definitivo do campeonato:**

*Investir muito (Chelsea, Tottenham, Man United) não garante nada sem:*

1. *Domínio de jogo (chutes + escanteios)*
2. *Disciplina tática (poucas faltas)*
3. *Eficiência ofensiva (vitórias)*
4. *Regularidade psicológica*

*Man City prova que o equilíbrio entre investimento inteligente e desempenho em campo é a verdadeira fórmula do título. Aston Villa mostra que é possível ir longe com orçamento limitado. Chelsea é a lição de que dinheiro sozinho não joga futebol.*`
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  main.variable(observer()).define(["md"], _1);
  main.variable(observer("dados")).define("dados", ["d3"], _dados);
  main.variable(observer("embed")).define("embed", ["require"], _embed);
  main.variable(observer()).define(["embed"], _4);
  main.variable(observer("cell31")).define("cell31", ["md"], _cell31);
  main.variable(observer("Plot")).define("Plot", ["require"], _Plot);
  main.variable(observer("resultados")).define("resultados", ["dados"], _resultados);
  main.variable(observer()).define(["Plot","resultados"], _8);
  main.variable(observer()).define(["md"], _9);
  main.variable(observer("plotComparacaoTriplaHorizontalFora")).define("plotComparacaoTriplaHorizontalFora", ["d3","Plot"], _plotComparacaoTriplaHorizontalFora);
  main.variable(observer()).define(["md"], _11);
  main.variable(observer("plotComparacaoFaltasHorizontal")).define("plotComparacaoFaltasHorizontal", ["d3","Plot"], _plotComparacaoFaltasHorizontal);
  main.variable(observer()).define(["md"], _13);
  main.variable(observer("plotInvestimentosHorizontal")).define("plotInvestimentosHorizontal", ["d3","Plot"], _plotInvestimentosHorizontal);
  main.variable(observer()).define(["md"], _15);
  main.variable(observer("plotComparacaoDumbbell")).define("plotComparacaoDumbbell", ["d3","Plot"], _plotComparacaoDumbbell);
  main.variable(observer()).define(["md"], _17);
  main.variable(observer("plotComparacaoEscanteiosEstilizado")).define("plotComparacaoEscanteiosEstilizado", ["d3","Plot"], _plotComparacaoEscanteiosEstilizado);
  main.variable(observer()).define(["md"], _19);
  main.variable(observer("plotComparacaoCampeaoVice")).define("plotComparacaoCampeaoVice", ["d3","Plot"], _plotComparacaoCampeaoVice);
  main.variable(observer()).define(["md"], _21);
  main.variable(observer("plotComparacaoInvestimento")).define("plotComparacaoInvestimento", ["d3","Plot"], _plotComparacaoInvestimento);
  main.variable(observer()).define(["md"], _23);
  main.variable(observer("plotInvestimentoVsPosicao")).define("plotInvestimentoVsPosicao", ["d3","Plot"], _plotInvestimentoVsPosicao);
  main.variable(observer()).define(["md"], _25);
  return main;
}
